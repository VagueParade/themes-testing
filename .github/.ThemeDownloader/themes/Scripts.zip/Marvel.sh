#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Marvel.zip"
THEME_NAME="Marvel"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Marvel.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Marvel.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Marvel.zip"
SH_NAME="Marvel.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Marvel.png"
CREDITS_INFO="by: Kirito_01" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
