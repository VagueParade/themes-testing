#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Yu-Gi-OS.zip"
THEME_NAME="Yu-Gi-OS"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Yu-Gi-OS.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Yu-Gi-OS.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Yu-Gi-OS.zip"
SH_NAME="Yu-Gi-OS.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Yu-Gi-OS.png"
CREDITS_INFO="by: Emulation Otaku" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
