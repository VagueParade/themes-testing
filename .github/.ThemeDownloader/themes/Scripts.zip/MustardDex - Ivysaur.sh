#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/MustardDex.-.Ivysaur.zip"
THEME_NAME="MustardDex - Ivysaur"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/MustardDex - Ivysaur.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/MustardDex - Ivysaur.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/MustardDex - Ivysaur.zip"
SH_NAME="MustardDex - Ivysaur.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/MustardDex%20-%20Ivysaur.png"
CREDITS_INFO="by: LMarcoMiranda" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
