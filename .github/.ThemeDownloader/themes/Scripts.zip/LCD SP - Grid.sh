#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/LCD.SP.-.Grid.zip"
THEME_NAME="LCD SP - Grid"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/LCD SP - Grid.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/LCD SP - Grid.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/LCD SP - Grid.zip"
SH_NAME="LCD SP - Grid.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/LCD%20SP%20-%20Grid.png"
CREDITS_INFO="by: Merkin (original: antiKk)" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
