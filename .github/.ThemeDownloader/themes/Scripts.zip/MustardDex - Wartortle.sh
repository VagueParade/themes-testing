#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/MustardDex.-.Wartortle.zip"
THEME_NAME="MustardDex - Wartortle"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/MustardDex - Wartortle.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/MustardDex - Wartortle.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/MustardDex - Wartortle.zip"
SH_NAME="MustardDex - Wartortle.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/MustardDex%20-%20Wartortle.png"
CREDITS_INFO="by: LMarcoMiranda" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
