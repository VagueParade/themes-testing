#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Pokemon.Lets.Go.Pikachu.zip"
THEME_NAME="Pokemon Lets Go Pikachu"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Pokemon Lets Go Pikachu.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Pokemon Lets Go Pikachu.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Pokemon Lets Go Pikachu.zip"
SH_NAME="Pokemon Lets Go Pikachu.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Pokemon%20Lets%20Go%20Pikachu.png"
CREDITS_INFO="by: RYX" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
