#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Tang-o-roundient.A.zip"
THEME_NAME="Tang-o-roundient A"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Tang-o-roundient A.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Tang-o-roundient A.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Tang-o-roundient A.zip"
SH_NAME="Tang-o-roundient A.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Tang-o-roundient%20A.png"
CREDITS_INFO="by: tiduscrying" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
