#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/MustardDex.-.Venusaur.zip"
THEME_NAME="MustardDex - Venusaur"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/MustardDex - Venusaur.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/MustardDex - Venusaur.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/MustardDex - Venusaur.zip"
SH_NAME="MustardDex - Venusaur.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/MustardDex%20-%20Venusaur.png"
CREDITS_INFO="by: LMarcoMiranda" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
