#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/muOS.-.Mup.zip"
THEME_NAME="muOS - Mup"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/muOS - Mup.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/muOS - Mup.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/muOS - Mup.zip"
SH_NAME="muOS - Mup.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/muOS%20-%20Mup.png"
CREDITS_INFO="by: nap" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
