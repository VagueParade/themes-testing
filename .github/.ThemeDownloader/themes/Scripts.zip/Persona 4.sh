#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Persona.4.zip"
THEME_NAME="Persona 4"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Persona 4.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Persona 4.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Persona 4.zip"
SH_NAME="Persona 4.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Persona%204.png"
CREDITS_INFO="by: Jdan-S" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
