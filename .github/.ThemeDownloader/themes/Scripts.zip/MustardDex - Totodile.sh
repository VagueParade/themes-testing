#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/MustardDex.-.Totodile.zip"
THEME_NAME="MustardDex - Totodile"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/MustardDex - Totodile.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/MustardDex - Totodile.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/MustardDex - Totodile.zip"
SH_NAME="MustardDex - Totodile.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/MustardDex%20-%20Totodile.png"
CREDITS_INFO="by: LMarcoMiranda" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
