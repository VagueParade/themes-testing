#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Golden.Sun.zip"
THEME_NAME="Golden Sun"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Golden Sun.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Golden Sun.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Golden Sun.zip"
SH_NAME="Golden Sun.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Golden%20Sun.png"
CREDITS_INFO="by: RYX" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
