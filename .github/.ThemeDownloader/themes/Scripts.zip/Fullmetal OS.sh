#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Fullmetal.OS.zip"
THEME_NAME="Fullmetal OS"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Fullmetal OS.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Fullmetal OS.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Fullmetal OS.zip"
SH_NAME="Fullmetal OS.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Fullmetal%20OS.png"
CREDITS_INFO="by: Emulation Otaku" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
