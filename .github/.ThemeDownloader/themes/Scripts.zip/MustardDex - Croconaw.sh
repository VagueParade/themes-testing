#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/MustardDex.-.Croconaw.zip"
THEME_NAME="MustardDex - Croconaw"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/MustardDex - Croconaw.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/MustardDex - Croconaw.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/MustardDex - Croconaw.zip"
SH_NAME="MustardDex - Croconaw.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/MustardDex%20-%20Croconaw.png"
CREDITS_INFO="by: LMarcoMiranda" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
