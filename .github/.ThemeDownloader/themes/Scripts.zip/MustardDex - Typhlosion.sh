#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/MustardDex.-.Typhlosion.zip"
THEME_NAME="MustardDex - Typhlosion"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/MustardDex - Typhlosion.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/MustardDex - Typhlosion.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/MustardDex - Typhlosion.zip"
SH_NAME="MustardDex - Typhlosion.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/MustardDex%20-%20Typhlosion.png"
CREDITS_INFO="by: LMarcoMiranda" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
