#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/breath-of-fire-4-ryx.zip"
THEME_NAME="breath-of-fire-4-ryx"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/breath-of-fire-4-ryx.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/breath-of-fire-4-ryx.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/breath-of-fire-4-ryx.zip"
SH_NAME="breath-of-fire-4-ryx.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/breath-of-fire-4-ryx.png"
CREDITS_INFO="by: RYX" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
