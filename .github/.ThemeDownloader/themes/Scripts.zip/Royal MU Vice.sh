#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Royal.MU.Vice.zip"
THEME_NAME="Royal MU Vice"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Royal MU Vice.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Royal MU Vice.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Royal MU Vice.zip"
SH_NAME="Royal MU Vice.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Royal%20MU%20Vice.png"
CREDITS_INFO="by: Kee Whi" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
